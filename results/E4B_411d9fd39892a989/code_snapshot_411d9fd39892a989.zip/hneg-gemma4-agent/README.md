# Deterministic Loop Breaking: A Hierarchical Neuro-Symbolic State-Machine Architecture for Graph-Based Code Comprehension in Gemma 4 Agents

**Track Category Submission:** Overall Best Paper / Best New Application  
**Target Foundation:** `gemma-4-31b-it-qat-w4a16-ct` / `gemma-4-26b-a4b`  
**Artifact License:** [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0)  

## Quickstart

```bash
pip install -r requirements.txt          # Python >= 3.10
python -m pytest -q tests                # CPU-only unit tests (no model needed)

# 1. Build the 120-bug task file from SWE-bench Lite (clones repos, applies test patches)
python experiments/prepare_tasks.py --repos-dir /data/swe --out experiments/tasks.jsonl \
    --env-prefix "conda run -n swe_{repo_slug}_{version}"   # per-repo test environment

# 2. Run the ablation (GPU + Gemma 4 weights); resumable, records run_meta.json
python experiments/run_benchmark.py --tasks experiments/tasks.jsonl \
    --configs baseline baseline_k3 reflex_only static_mask full \
    --trace-dir experiments/traces --ablation-csv experiments/results_ablation.csv

# 2b. Ablation table + savings with 95% bootstrap CIs (savings_report.md / savings.json)
python experiments/savings_report.py --results-dir experiments/results

# 2c. Check every claim of the paper: VERIFIED / NOT SUPPORTED / INCONCLUSIVE (claims_verification.md)
python experiments/verify_claims.py --results-dir experiments/results --gpu-cost-per-hour 0.35

# 3. Loop 3 offline calibration over the recorded traces
python -m src.state_machine experiments/traces
```

### Sandbox: Gemma 4 E2B / E4B GGUF (one Kaggle T4, 8–12 GB VRAM, or CPU)

Verify the masking and state-machine controllers on a small quantized model before moving to the 31B
checkpoint. The same H-NEG core runs through llama.cpp
([`src/llamacpp_backend.py`](src/llamacpp_backend.py)) on
| Model (GGUF) | Size | Use |
| :--- | :---: | :--- |
| [`unsloth/gemma-4-E2B-it-GGUF`](https://huggingface.co/unsloth/gemma-4-E2B-it-GGUF) · `gemma-4-E2B-it-Q4_K_M.gguf` | 3.1 GB | **default**: fastest controller checks; fits one T4 with a 16K context |
| [`unsloth/gemma-4-E4B-it-GGUF`](https://huggingface.co/unsloth/gemma-4-E4B-it-GGUF) · `gemma-4-E4B-it-Q4_K_M.gguf` | 5.0 GB | better repair quality for a pilot benchmark |

Configured under `sandbox:` in `hneg_config.yaml`; switch with `--gguf-repo/--gguf-file`.
Don't load a GGUF with `transformers`: it de-quantizes to full precision.

```bash
pip install llama-cpp-python huggingface_hub     # CUDA: CMAKE_ARGS="-DGGML_CUDA=on" pip install llama-cpp-python
python experiments/sandbox_smoke.py               # downloads E2B Q4_K_M once (HF cache), runs the checks
python experiments/sandbox_smoke.py --gguf-repo unsloth/gemma-4-E4B-it-GGUF --gguf-file gemma-4-E4B-it-Q4_K_M.gguf
python experiments/sandbox_smoke.py --n-gpu-layers 0          # CPU only
python experiments/run_benchmark.py --backend gguf --tasks experiments/tasks.jsonl --limit 10
```

`sandbox_smoke.py` exits non-zero unless all of these hold with the real tokenizer and decoder:
- the gate masks the out-of-scope `secure_compare`,
- the trie prevents any retry from replaying a failed token sequence,
- the run halts at `K_max`.

It then attempts one real repair and reports the result. Use the sandbox to check that the
controllers *work*. Its Pass@1, latency and token figures don't carry over to the 31B model, so
don't report them as results for 31B.

### Running on Kaggle (GPU T4)

[`notebooks/HNEG_Kaggle_Run.ipynb`](notebooks/HNEG_Kaggle_Run.ipynb) runs everything step by step:
environment check, CUDA build of llama.cpp (cached as a wheel), tests, E2B sandbox checks, a
**validated** SWE-bench pilot, a resumable ablation run, and calibration.

Kaggle has no Docker, so `prepare_tasks.py --validate` keeps only instances whose FAIL_TO_PASS tests
fail on the original code and pass with the official fix in that environment. `run_benchmark.py`
appends results per bug, resumes on rerun, and stops cleanly with `--time-budget-hours`.

Minimal use inside your own generation loop:

```python
from transformers import LogitsProcessorList
from src import CodePropertyGraph, IdentifierScopeGate, FailedDiffTrie, HNEGLogitsProcessor

cpg   = CodePropertyGraph.from_repo("path/to/repo")
gate  = IdentifierScopeGate(tokenizer, cpg.symbol_allowlist("pkg/module.py"))
trie  = FailedDiffTrie(min_prefix_len=8)
proc  = HNEGLogitsProcessor(tokenizer, failed_trie=trie, grammar_gate=gate)
proc.reset(patch_start=input_ids.shape[1])
out = model.generate(input_ids, logits_processor=LogitsProcessorList([proc]))
# on a failed patch: trie.insert(out[0, input_ids.shape[1]:].tolist())
```

---

## 1. Executive Summary & Research Motivation

Deploying autonomous software engineering (SWE) developer agents locally on consumer-tier workstations using open-weight foundations—such as Google DeepMind's [Gemma family of models](https://arxiv.org/abs/2408.00118)—introduces a critical operational bottleneck: the **Agentic Compute Tax**.

In conventional unconstrained agentic architectures (e.g., standard ReAct or flat self-repair loops), stochastic next-token predictors enter compounding failure loops when encountering compiler, syntax, or test suite errors. Because statistical language models lack intrinsic structural halting mechanisms, the generator repeatedly emits near-identical code diffs with superficial string variations. The total computational cost of an unconstrained agentic session across $T$ turns is formalized as:

$$
\text{Cost}_{\text{Agent}} = \sum_{t=1}^{T} \left( \text{Tokens}_{\text{in}}^{(t)} \cdot \tau_{\text{prefill}} + \text{Tokens}_{\text{out}}^{(t)} \cdot \tau_{\text{decode}} + \text{Container Overhead}^{(t)} \right)
$$

Under recursive failure, $\text{Tokens}_{\text{in}}^{(t)}$ scales quadratically as terminal tracebacks accumulate, precipitating three systemic failures on localized hardware:
1. **Severe Context Window Pollution:** Rapid accumulation of terminal tracebacks degrades the attention mechanism’s Signal-to-Noise Ratio (SNR).
2. **Local Hardware Saturation:** Memory-bandwidth starvation and KV-cache saturation force consumer GPUs (e.g., 24GB VRAM) into out-of-memory (OOM) disk paging.
3. **Runaway Compute Expenditure:** Unbounded multi-turn exploration loops lead to excessive container churn without converging on a valid patch.

### Deconstructing the "Long-Context Fallacy"
A common assumption in literature is that expanding context windows (e.g., Gemma 4's native 256K context via Proportional RoPE) eliminates agentic failure states. Empirical analysis proves the inverse: **larger context windows exacerbate local failure loops**. A statistical model trapped in an error cycle does not break free simply because it has additional token capacity; it merely consumes more tokens before failing, while suffering from attention dispersion and increased Time-To-First-Token (TTFT) latency. 

Operational efficiency is therefore governed not by expanding context capacity, but by **enforcing deterministic structural boundaries at token emission**.

```text
CONTEXT WINDOW UTILIZATION OVER MULTI-TURN REPAIR
===================================================================================
[ Tokens in Context ]
  256K ──┐ (Gemma 4 Maximum Ceiling)
         │                                                      / Unconstrained Agent
  128K ──┤                                                     /  (Polluted Context,
         │                                                    /    High Latency, OOM Risk)
   64K ──┤                                                   /
   16K ──┤                                    ┌────────────┘
    4K ──┤          ┌───────────┘
    1K ──┼──────────┴─────────────────────────────────────────────────────────────►
         └────────────────────────────────────────────────────────────────────────
           Turn 1     Turn 2     Turn 3      Turn 4 (Halt)          Turn N
                               [ Execution Turns ]
===================================================================================
```

---

## 2. Core Architecture: The H-NEG Framework

**H-NEG (Hierarchical Neuro-Symbolic Execution Governance)** decouples statistical perception from symbolic execution by implementing a dual-layer runtime system:

```text
======================================================================================================
                              H-NEG DUAL-LAYER NEURO-SYMBOLIC RUNTIME
======================================================================================================

 [ MACRO-GOVERNANCE: Dynamic Pushdown Statechart ]
   • Stack-Based State Allocation: S_t = < Phase, File_Scope, AST_Node, Depth >
   • Three-Loop Execution Isolation (Reflex < 50ms | Convergence k <= 3 | Offline Calibration)
   • Context Integrity Contract (SR_id) binds active worktree snapshot to Code Property Graph (CPG)
                           │
                           ▼ (Transfers Active Scope & Symbol Allowlist)
 [ MICRO-GOVERNANCE: Inline Token-Logit Engine ]
   • Injected into Gemma 4 between Logit Soft-Capping and MTP Drafter Head
   • Constrained Logit Projection: z'_t = SoftCap(z_t) + M_t
   • Dual Masking: (1) Pushdown Automaton Grammar Gate + (2) Anti-Loop Trie Failure Exclusion
   • Speculative Candidate Pruning: Rejects syntactically invalid MTP draft tokens prior to verification
======================================================================================================
```

### 2.1 Micro-Layer: Inline CFG & Trie-Pruned Logit Masking
H-NEG intercepts decoding natively inside Gemma 4 immediately following [Logit Soft-Capping](https://newsletter.maartengrootendorst.com/p/a-visual-guide-to-gemma-4) [1] and upstream of the Multi-Token Prediction (MTP) Drafter Head.

First, raw logits $z_t \in \mathbb{R}^{|\mathcal{V}|}$ produced by the final transformer unembedding projection pass through Gemma's soft-capping operator:

$$
z_t^{\text{capped}} = C_{\text{cap}} \cdot \tanh\left(\frac{z_t}{C_{\text{cap}}}\right)
$$

The symbolic engine intercepts $z_t^{\text{capped}}$ by adding a dynamic mask vector $M_t \in \{0, -\infty\}^{|\mathcal{V}|}$:

$$
\tilde{z}_t(v) = z_t^{\text{capped}}(v) + M_t(v)
$$

The constrained probability distribution sampled by the LM head is:

$$
P(y_t = v \mid y_{<t}) = \frac{\exp(\tilde{z}_t(v))}{\sum_{j \in \mathcal{V}} \exp(\tilde{z}_t(j))}
$$

The dynamic mask vector $M_t(v)$ is computed per step:

$$
M_t(v) = \begin{cases} 
0 & \text{if } v \in \text{ValidTokens}(S_t) \ \wedge \ v \notin \text{TriePrune}(\mathcal{H}_{\text{failed}}) \\ 
-\infty & \text{otherwise} 
\end{cases}
$$

1. **Pushdown Automaton Grammar Gate ($\text{ValidTokens}(S_t)$):** Enforces target language syntax (Python, Rust, C++) and Code Property Graph identifier scopes via a deterministic parser, adapting concepts from [SynCode](https://arxiv.org/abs/2403.01632) [2] and [Grammar-Aligned Decoding](https://arxiv.org/abs/2307.09702) [3]. Out-of-scope identifiers or unparseable syntax receive a probability of zero, ensuring an **absolute 0.0% Parse Failure Rate (PFR)**.
2. **Anti-Loop Trie Pruning ($\text{TriePrune}(\mathcal{H}_{\text{failed}})$):** To resolve the technical limitation of post-hoc cryptographic diff-hashing, H-NEG maintains an in-memory prefix trie $\mathcal{H}_{\text{failed}}$ containing all failed patch token sequences from prior iterations. If the generator begins replicating an identical token prefix, the continuation token is masked to $-\infty$, mathematically compelling beam search to explore alternative solution paths.
3. **MTP Speculative Branch Filtering:** Gemma 4's MTP drafter head generates parallel speculative tokens. H-NEG filters this speculative candidate tree against the grammar automaton $S_t$, pruning invalid speculative paths before verification.

### 2.2 Macro-Layer: Dynamic Pushdown Statecharts
Unlike rigid Finite State Machines with static enums, H-NEG formalizes repository navigation as a **Hierarchical Pushdown Automaton (PDA)**. States are dynamically instantiated at runtime as attributed execution frames:

$$
S_t = \langle \Phi, \mathcal{F}, \Sigma_{\text{AST}}, \delta \rangle
$$

* $\Phi \in \{\text{REPO\_ANALYSIS}, \text{CODE\_EDIT}, \text{RESOLVE\_DEP}, \text{LOCAL\_COMPILATION}, \dots\}$ represents the macro task phase.
* $\mathcal{F}$ anchors the workspace file boundary (e.g., `src/auth/jwt.py`).
* $\Sigma_{\text{AST}}$ binds the active subtree of the [Code Property Graph (CPG)](https://ieeexplore.ieee.org/document/6956589) [4] (e.g., `verify_token::Node_0x4F1`).
* $\delta \in \mathbb{N}$ represents the recursive call stack depth bounded by $\delta \le \delta_{\max}$.

When recursive sub-tasks arise (e.g., finding a missing import while modifying an existing method), the engine **pushes** a child sub-state onto the stack:

$$
\text{Push}: \quad \mathcal{S}_{\text{stack}} \leftarrow \mathcal{S}_{\text{stack}} \cup \{ S_{\text{child}} \}
$$

Once resolved, it **pops** the sub-state and resumes the parent state with zero context pollution:

$$
\text{Pop}: \quad S_{\text{resumed}} \leftarrow \text{top}(\mathcal{S}_{\text{stack}})
$$

---

## 3. The Three-Loop Hierarchical Model

System operations are isolated and scheduled according to computational latency:

```mermaid
flowchart TD
    Task["Incoming Bug / Task"] --> Contract["Generate Context Contract (SR_id + CPG)"]
    Contract --> Gen["Gemma Generation with Inline Masking"]
    
    subgraph LOOP1["Loop 1: The Reflex Loop (<50ms)"]
        Gen --> AST{"AST & Type Check Passes?"}
    end

    AST -- Yes --> Patch["Emit Verified Patch"]
    
    subgraph LOOP2["Loop 2: The Convergence Loop (Neural Recovery)"]
        AST -- No --> Incr["Increment Counter: k = k + 1"]
        Incr --> CheckLimit{"k ≤ K_max (3)?"}
        CheckLimit -- Yes --> Retry["Inject Diagnostic Trace into Context"]
        Retry --> Gen
        CheckLimit -- No --> Halt["Trigger GRACEFUL_HALT<br/>(Deterministic Stop)"]
    end

    subgraph LOOP3["Loop 3: The Calibration Loop (Offline Trace)"]
        Patch -.-> TraceLog["Trace Event Log"]
        Halt -.-> TraceLog
        TraceLog --> Calibrate["Update Dynamic Routing & Ranking Heuristics"]
    end
    
    Calibrate -.->|"Calibrated Heuristics"| Contract
```

* **Loop 1: The Reflex Loop ($< 50\text{ms}$):** Executes fast, in-memory symbolic validation (AST integrity, indentation checks, local type conformity). Syntax failures are caught instantaneously before launching containers.
* **Loop 2: The Convergence Loop ($K \le 3$):** Manages multi-turn neural reasoning recovery. The model is bounded to a hard ceiling of $K=3$ attempts. If unresolved, it triggers a deterministic `GRACEFUL_HALT` state to protect local compute budgets.
* **Loop 3: The Calibration Loop (Offline):** Operates asynchronously across completed trace logs, updating dynamic routing heuristics without modifying model weights.

---

## 4. State-Transition Reference Matrix

| Source State | Trigger Event | Target State | Hard Symbolic Safeguard |
| :--- | :--- | :--- | :--- |
| `REPO_ANALYSIS` | Target File / Symbol Located | `CODE_EDIT` | Logit-mask restricts parameters to existing CPG nodes. |
| `CODE_EDIT` | Missing Dep Detected | `RESOLVE_DEP` (Push Stack) | Pushes parent state; scopes context strictly to dependency. |
| `RESOLVE_DEP` | Dep Compiled Successfully | `CODE_EDIT` (Pop Stack) | Pops stack frame; restores parent editing context. |
| `CODE_EDIT` | Patch Token Stream Emitted | `LOCAL_COMPILATION` | Inline CFG parser enforces language grammar; Trie-prunes failed prefixes. |
| `LOCAL_COMPILATION` | Exit Code $\ne 0$ (Failure) | `REPO_ANALYSIS` | Updates failure Trie $\mathcal{H}_{\text{failed}}$; increments attempt counter $k$. |
| `LOCAL_COMPILATION` | Exit Code $= 0$ (Success) | `SYMBOLIC_VALIDATION`| Forwards verified build to local test suites. |
| `ANY` | Retry Counter $k \ge 3$ | `GRACEFUL_HALT` | Enforces emergency stop to preserve token and time budgets. |

---

## 5. Declarative Control Schema (`hneg_config.yaml`)

```yaml
agent:
  name: "Gemma4-HNEG-Agent"
  version: "1.0.0"
  model_id: "gemma-4-31b-it-qat-w4a16-ct"
  runtime: "local-offline"

governance:
  max_convergence_retries: 3
  max_pda_stack_depth: 4
  strict_mode: true
  enable_graceful_halt: true

symbolic_engine:
  inline_cfg_masking: true
  trie_prefix_exclusion: true
  cpg_dependency_check: true
  reflex_latency_cap_ms: 50

tool_state_matrix:
  - tool_name: "query_cpg_graph"
    allowed_state: "REPO_ANALYSIS"
  - tool_name: "emit_structured_patch"
    allowed_state: "CODE_EDIT"
  - tool_name: "resolve_external_symbol"
    allowed_state: "RESOLVE_DEP"
  - tool_name: "run_test_suite"
    allowed_state: "SYMBOLIC_VALIDATION"
```

---

## 6. Experimental Evaluation & Benchmark Results

> **Status: the figures in 6.3 are hypothesised targets, not measurements.** They come from the
> original draft and were not produced by this code. Measured results are reported only in 6.4,
> each with its model, sample size and confidence intervals. Results from the E2B/E4B sandbox models
> are not 31B results.

### 6.1 Evaluation Design
* **Target setting (not yet run):** `gemma-4-31b-it-qat-w4a16-ct` on a single local workstation (e.g. 1× RTX 4090 24 GB), offline.
* **Sandbox setting (runnable today):** Gemma 4 E4B / E2B Q4_K_M GGUF through llama.cpp on one Kaggle T4.
* **Configurations:** `baseline` (unconstrained, ≤ 10 attempts, full transcript), `baseline_k3` (same 3-attempt cap and short context as H-NEG, no governance), `reflex_only`, `static_mask` (identifier-scope masking), `full` (+ edit-level anti-replay and the pushdown state machine with GRACEFUL_HALT). The decisive comparison is `full vs baseline_k3`.
* **Tasks:** SWE-bench Lite instances validated in the run environment (target tests fail on the original code and pass with the official fix). The draft's target is 120 issues; the current Kaggle pilot set has 20 SymPy tasks. Local test passes are not official SWE-bench grading.
* **Analysis:** `savings_report.py` (paired bootstrap 95% CIs) and `verify_claims.py` (VERIFIED / NOT SUPPORTED / INCONCLUSIVE per claim, exact McNemar tests on resolution).

### 6.2 Token Overhead & Efficiency Metrics
We evaluate the token waste ratio $T_{\text{waste}}$ defined as:

$$
T_{\text{waste}} = \frac{T_{\text{total}} - T_{\text{final\_patch}}}{T_{\text{total}}}
$$

"Pass@1" in the generated tables means *resolved within the configuration's attempt budget*, not first-attempt
success. The loop rate is operational: attempts exhausted while re-submitting an identical patch.

### 6.3 Hypothesised Targets (from the draft — not measured)

| System Configuration | Parse Failure Rate (PFR) | Infinite Loop Rate (%) | Mean Token Footprint per Bug | Mean Run Latency (s) | Issue Resolution Rate |
| :--- | :---: | :---: | :---: | :---: | :---: |
| Baseline Gemma 31B (Unconstrained) | *14.2%* | *42.1%* | *8,420* | *184.2s* | *19.2%* |
| Gemma + Loop 1 Reflex Only | *5.8%* | *23.4%* | *5,110* | *112.6s* | *24.1%* |
| Gemma + Identifier-Scope Logit Masking | *0.0%* | *16.7%* | *3,890* | *88.4s* | *26.5%* |
| Full H-NEG Pipeline | *0.0%* | *0.0%* | *1,940* | *46.8s* | *31.8%* |

These targets imply a 64.2% token reduction and a 3.93× speedup. They have not been measured, the
table has no `baseline_k3` row, and the draft's PFR of 0.0% assumes a full grammar engine that this
reference implementation does not include (its gate restricts identifier scope only).

### 6.4 Measured Results

| Date | Model | Tasks (n) | Outcome |
| :--- | :--- | :---: | :--- |
| 2026-11 | Gemma 4 E2B Q4_K_M (GGUF), Kaggle T4 | 2 (SymPy) | Pipeline ran end to end. No configuration produced an applicable edit (PFR 100%), so nothing was resolved and cost per resolved bug is undefined. Only `full` never re-submitted an identical failed patch (the other four did on both bugs). Ran before the edit-level anti-replay guard was added. |
| 2026-11-11 | Gemma 4 E4B Q4_K_M (GGUF), Kaggle T4, code `7885d3d615d4a3bc` | 2 (SymPy) | Edits now well-formed and applied (PFR 5–25% outside `full`, was 100%); tests ran on every applied edit. No configuration resolved either bug (semantically wrong fixes). `full` and `baseline_k3` both cut tokens ~81% and time ~7× vs `baseline`; `full vs baseline_k3`: 3.3% fewer tokens [CI −0.0, 9.4], 0.87× speed — no measurable governance benefit. Guarantees C1–C3 held; C4 failed because the replay guard let the model escape via a second `=======` separator (fixed afterwards). |
| pending | Gemma 4 E4B Q4_K_M (GGUF), Kaggle T4 | 20 (SymPy) | Not yet run. Report from `savings_report.md` and `claims_verification.md`, citing `run_meta.json`. |

`experiments/results_ablation.csv` holds only the column header until a real run writes it with
`--ablation-csv`.

---

## 7. Multimodal & Universal Action-Space Generalization

While evaluated on software engineering repositories, H-NEG’s decoupling of neural inference from symbolic decoding extends to any multimodal domain where the action space exhibits formal grammar:
* **Visual UI (Design-to-Code):** Ingests screenshot tokens; masks output tokens against CSS and HTML DOM tree pushdown automata.
* **Embodied AI & Robotics:** Ingests camera streams; constrains tool-calling logits against physical kinematic graphs and URDF obstacle bounds.
* **Structured Data Extraction:** Ingests document images; bounds output tokens strictly to valid FHIR JSON schemas with 0% parse failures.

---

## 8. Reproducibility & Open Source Compliance

```text
hneg-gemma4-agent/
├── hneg_config.yaml            declarative control schema
├── src/
│   ├── logit_masker.py         FailedDiffTrie, EditReplayGuard, IdentifierScopeGate, HNEGLogitsProcessor, filter_draft_tokens
│   ├── state_machine.py        DynamicStateManager (PDA), GRACEFUL_HALT, Loop 3 calibrate_from_traces
│   ├── cpg_parser.py           CodePropertyGraph (ast + tree-sitter), SR_id, reflex_check (Loop 1)
│   └── llamacpp_backend.py     GGUF sandbox: GGUFRunner, LlamaCppTokenizer, NumpyLogitsAdapter
├── experiments/
│   ├── prepare_tasks.py        SWE-bench Lite -> tasks.jsonl (seeded sample; --repos filter, --validate)
│   ├── common.py               sandboxed test execution shared by the scripts
│   ├── run_benchmark.py        ablation harness (baseline / baseline_k3 / reflex_only / static_mask / full; --backend hf|gguf)
│   ├── savings_report.py       ablation table + paired savings with 95% bootstrap CIs
│   ├── verify_claims.py        each paper claim -> VERIFIED / NOT SUPPORTED / INCONCLUSIVE
│   ├── edit_format.py          SEARCH/REPLACE parsing, fuzzy application, code-context excerpt
│   ├── sandbox_smoke.py        E4B GGUF functional checks (gate, trie, GRACEFUL_HALT)
│   └── results_ablation.csv    header only; a real run writes it with --ablation-csv
├── tests/                      pytest suite for all components
└── notebooks/
    ├── HNEG_Gemma4_Demo.ipynb  walkthrough of each component
    └── HNEG_Kaggle_Run.ipynb   step-by-step Kaggle pipeline (T4)
```

**Implementation notes.** The reference `ValidTokens(S_t)` gate (`IdentifierScopeGate`) restricts
*referenced bare names* to the CPG allowlist plus names the patch binds itself; it leaves
attributes, import lines, and binding positions unconstrained. Full CFG enforcement
plugs in through the `grammar_gate` interface (e.g. a SynCode/XGrammar adapter). The `static_mask`
ablation uses this identifier gate.

**Patch format.** By default the model replies with SEARCH/REPLACE edit blocks
([`experiments/edit_format.py`](experiments/edit_format.py)). They are applied to the real file, and
the reflex check and tests then run on the result. An edit that can't be applied counts as a parse
failure. Files longer than `--context-chars` are shown as the import header plus the definitions
named in the issue. That excerpt is deterministic and identical for every configuration.
`--patch-format full` restores whole-file output. The parser also accepts unified diffs, SEARCH text is
matched exactly, then ignoring whitespace, then by a unique fuzzy match (difflib ratio ≥ 0.9), and a
failed edit's retry message shows the closest lines of the file. All of this applies to every
configuration.

**Anti-replay for edits.** With edit blocks, a token-level trie over the whole reply is the wrong unit:
every reply starts with the same fence, marker and anchor lines copied from the file, so masking after
a shared prefix pushes the model *off* correct anchors. In edit mode the full pipeline therefore uses
`EditReplayGuard`, which masks only the token that would *complete* a no-op edit, an already-failed
(SEARCH, REPLACE) pair, or a SEARCH text that was already not found. `FailedDiffTrie` remains in use for
whole-file patches.

**Reading the ablation.** `baseline_k3` gets the same retry cap (K_max) and short context as the full
pipeline but none of the governance layers, so `full vs baseline_k3` measures what masking, the trie
and the state machine add beyond stopping early. The infinite-loop rate uses one definition for every
configuration: retries exhausted (cap or GRACEFUL_HALT) without a fix while re-submitting an identical
patch. Table values should be copied from `savings_report.md`, which states the model SHA-256 and n.

**Verifying the claims.** `verify_claims.py` splits the paper's claims in two. *Guarantees* (loop
elimination, the K_max bound, no re-submitted failed patch, 0% syntax failures, no out-of-scope
names) are properties of the controller and can be checked on any model at any n. *Effects*
(token reduction, speedup, Pass@1, cost per resolved bug, and above all `full vs baseline_k3`) are
statistical: they need resolved bugs, use paired bootstrap CIs and exact McNemar tests, and hold only
for the model that was run.

All configuration schemas, state-machine controllers, logit-masking processors, and benchmarking harnesses are open-sourced under the **Apache 2.0 License**.

* **Kaggle Demonstration Notebook:** [Link to your Public Kaggle Notebook]
* **GitHub Repository:** [Link to your Public GitHub Repository]

---

## 9. References

1. Grootendorst, M. (2026). *A Visual Guide to Gemma 4*. Available at: [https://newsletter.maartengrootendorst.com/p/a-visual-guide-to-gemma-4](https://newsletter.maartengrootendorst.com/p/a-visual-guide-to-gemma-4) [1].
2. Ugare, S., Suresh, T., Kang, H., et al. (2024). *SynCode: LLM Generation Accompanied by Context-Free Grammar Parsing*. In *Advances in Neural Information Processing Systems (NeurIPS 2024)*. Available at: [https://arxiv.org/abs/2403.01632](https://arxiv.org/abs/2403.01632) [2].
3. Willard, B. T., & Louf, R. (2023). *Efficient Guided Generation for Large Language Models*. arXiv preprint. Available at: [https://arxiv.org/abs/2307.09702](https://arxiv.org/abs/2307.09702) [3].
4. Yamaguchi, F., Golde, N., Arp, D., & Rieck, K. (2014). *Modeling and Discovering Vulnerabilities with Code Property Graphs*. In *IEEE Symposium on Security and Privacy (S&P 2014)*. Available at: [https://ieeexplore.ieee.org/document/6956589](https://ieeexplore.ieee.org/document/6956589) [4].
5. Jimenez, C. E., Yang, J., Wettig, A., et al. (2024). *SWE-bench: Can Language Models Resolve Real-World GitHub Issues?* In *International Conference on Learning Representations (ICLR 2024)*. Available at: [https://arxiv.org/abs/2310.06770](https://arxiv.org/abs/2310.06770) [5].
6. Google DeepMind Gemma Team. (2024). *Gemma 2: Improving Open Language Models at a Practical Size*. arXiv preprint. Available at: [https://arxiv.org/abs/2408.00118](https://arxiv.org/abs/2408.00118) [6].
7. Vaswani, A., Shazeer, N., Parmar, N., et al. (2017). *Attention Is All You Need*. In *Advances in Neural Information Processing Systems (NeurIPS 2017)*. Available at: [https://arxiv.org/abs/1706.03762](https://arxiv.org/abs/1706.03762) [7].
8. Hugging Face Transformers. (2024). *LogitsProcessor Documentation and Generation Utilities*. Available at: [https://huggingface.co/docs/transformers/internal/generation_utils](https://huggingface.co/docs/transformers/internal/generation_utils) [8].
