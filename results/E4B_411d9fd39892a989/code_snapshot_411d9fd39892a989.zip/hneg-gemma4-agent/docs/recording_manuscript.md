# H-NEG: White-paper and implementation explanation (recording script)

English narration. It describes what the delivered repository actually implements, and keeps the white
paper's proposals and unmeasured figures clearly separate from implementation evidence.
Timestamps are approximate (about 150 words per minute); retime after a read-through.

---

## 00:00:00 — Motivation, controller and three loops

This recording explains H N E G: Hierarchical Neuro-Symbolic Execution Governance. The paper's title is
Deterministic Loop Breaking. The central question is simple: can we make a local A I coding agent spend
less compute repeating failed repairs, while making its behavior easier to inspect and reproduce?

We will walk through the motivation, the architecture, the Python implementation, and the evaluation.
Throughout, we separate three things: what the code actually does, what the white paper proposes beyond
the code, and what has actually been measured. That separation matters, because a working controller is
not the same thing as a demonstrated improvement on a software benchmark.

First, the problem. A coding agent reads an issue, proposes a change, runs tests, receives an error, and
tries again. That is useful when the next attempt makes progress. It becomes wasteful when the agent keeps
producing the same unsuccessful repair, or when every traceback is appended to an ever longer prompt.

The paper calls this the agentic compute tax. Its cost equation adds three terms across attempts: input
tokens multiplied by prefill cost, output tokens multiplied by decoding cost, and the overhead of preparing
and running the test environment. This is an accounting model, not a hardware law. Real costs depend on the
model, the hardware, the context length, and the execution environment.

One correction to the draft's growth claim. If each failed attempt appends roughly the same amount of text,
each prompt grows about linearly with the attempt number, so the total input tokens spent across all
attempts grows roughly quadratically. Individual prompts do not grow quadratically, and nothing here
grows exponentially.

Likewise, a larger context window does not by itself provide a stopping rule or guarantee a repair. But we
will not claim that longer contexts always make agents worse. The research question is whether explicit
execution boundaries and carefully chosen constraints reduce waste under controlled conditions.

The proposed answer has two levels. At the macro level, a controller decides which phase the agent is in
and what it may do next. At the micro level, a decoding processor restricts which tokens may be selected.

The controller is a pushdown state machine. Its phases include repository analysis, code editing,
dependency resolution, local compilation, and symbolic validation. Each frame records the phase, the active
file, an A S T node label, and the nesting depth. A S T means abstract syntax tree: a structured
representation of the program.

Imagine editing a function and temporarily investigating one of its dependencies. The controller pushes the
parent frame, enters the dependency frame, and later pops back to the parent. Push and pop preserve explicit
control state. They do not erase anything from the model's context, and they do not prove that context
pollution is zero.

Both the attempt count and the stack depth are bounded. The default allows three attempts in total,
including the first one, and a stack depth of four. If the third attempt passes the tests, the run succeeds:
success is checked before the attempt ceiling. If all three fail, the controller enters graceful halt. A halt
is an unresolved task, not a successful repair.

The three-loop structure divides the work. Loop one, the reflex loop, checks each candidate in memory before
any test runs: it must parse, and in the governed configurations it must not reference names outside the
repository's known symbols. The implementation measures and records this check's latency against a fifty
millisecond budget; it does not guarantee that budget. Loop two manages retries and keeps only the latest
diagnostic in the prompt. Loop three reads completed traces offline and recommends settings, such as the
retry ceiling. It never changes model weights, and a recommendation is applied only when someone merges it
into the configuration explicitly.

## 00:03:40 — Token masking, anti-replay and the code property graph

Now let's look inside the token-level intervention.

A language model assigns a score, called a logit, to every possible next token. The scores become
probabilities, and one token is selected. A symbolic mask can change which tokens are selectable without
retraining the model.

The white paper describes soft-capping the scores first: the capped score equals the cap multiplied by the
hyperbolic tangent of the raw score divided by the cap. In the delivered setup, llama dot C P P already
applies Gemma's soft-cap inside the model, so H N E G does not apply it a second time. H N E G then adds a
mask: an allowed token gets zero added to its score, a forbidden token gets negative infinity.

After normalization, a token with a score of negative infinity has zero probability, as long as at least one
token remains allowed. If the combined masks would forbid every token, the processor does not fall back to
unconstrained sampling. It first drops the anti-replay exclusion and keeps the scope mask. If that still
leaves nothing, it allows only the end-of-sequence token. Every such fallback is counted and logged.

Masking prevents forbidden continuations, but it redistributes probability over what remains. It does not
make the remaining options correct. Our runs use greedy decoding at temperature zero, identical for every
configuration.

The first mask is an identifier-scope gate, not a full grammar. It is applied inline, at every decoding
step, through llama dot C P P's logits-processor hook. It blocks tokens that would start a reference to a bare
name that is neither defined in the repository's symbol graph, nor a Python keyword or builtin, nor bound by
the patch itself. It deliberately leaves positions unconstrained where a new name may legitimately appear:
the start of a statement, after binding keywords like def, class, for or as, in parameter lists, on import
lines, after a dot, and inside strings and comments. So it is a conservative scope filter. It is not a
complete Python grammar, and it does not enforce syntax for Rust, JavaScript, or C plus plus. A full grammar
engine, such as a SynCode or XGrammar adapter, can be plugged into the same interface; that integration
remains future work.

After generation, every candidate is still checked separately: the edit must apply to the file, the result
must parse, the reflex check must pass, and the repository's tests must pass. A candidate that passes every
mask can still be the wrong repair.

The second intervention prevents replaying failures. The model answers with search-and-replace edit blocks:
lines copied from the file, followed by their replacement. A naive prefix trie over whole replies is the
wrong unit here, because every reply begins with the same markers and the same anchor lines copied from the
file. Blocking a shared prefix would push the model away from correct anchors. So in edit mode, the full
pipeline uses an edit-level replay guard. It masks only the single token that would complete one of three
known-bad things: an edit whose replacement equals its search text, a search-and-replace pair that has
already failed, or a search text that was already not found in the file. Comparison ignores whitespace, so
a cosmetic rewrite of a failed edit is also blocked. Everything else in the reply stays free.

For whole-file patches, the code keeps the original failed-diff trie. It stores the token sequences of
failed patches. Once a new patch shares at least eight tokens with a failed one, it masks the next token on
that failed path. That is stricter: it forces divergence early.

Either way, the mechanism prevents exact repetition. A differently written patch can still fail for the same
underlying reason. And the decoder samples tokens one at a time; it does not run the beam search that parts
of the draft describe.

The graph layer adds repository knowledge. The code builds a lightweight code property graph: Python files
through the standard A S T module, other languages through optional tree-sitter parsers. It records
definitions, parameters, module-level exports, imports and calls. A snapshot identifier, a hash over every
file and its content hash, binds this graph to the exact source it was built from, and each result records
that identifier.

The graph is used in two places: it supplies the allow-list for the scope mask, and it supplies the
allow-list for the reflex check. It is not injected into the prompt, it is not an embedding adapter, and it
does not modify model layers. Name resolution has known gaps, such as dynamic imports and attributes, which is
why the gate stays unconstrained in those positions.

Finally, the paper proposes filtering speculative multi-token drafts. The code contains a helper that trims a
draft token sequence to the longest prefix allowed by the same mask, but it is not connected to any M T P
drafter, and Gemma's drafter internals are not modified. A real integration would need branch-specific mask
state for both draft and target tokens. That remains future work.

## 00:08:30 — Implementation, evaluation, evidence and next steps

What have we actually built?

A Python reference project: a declarative configuration file, the state machine, the scope gate, replay
guard and trie, the logits processor, the code property graph, and two decoding backends, Hugging Face
transformers for the thirty-one-billion-parameter target, and llama dot C P P for quantized G G U F models.
It also includes SWE-bench task preparation with validation, a resumable benchmark harness, a savings report
with bootstrap confidence intervals, a claim-verification script, a Kaggle notebook, and unit tests. The
source is distributed under the Apache two point zero license.

How is a candidate evaluated? By default, the model replies with search-and-replace edit blocks. The parser
also accepts unified diffs. Search text is matched exactly first, then ignoring whitespace and indentation,
then by a single unambiguous fuzzy match. The edited file goes through the reflex check, and then the task's
test command runs in a fresh copy of the repository, with a timeout. A whole-file mode is available as an
option.

Copied workspaces are not security sandboxes. Generated code runs with the permissions of the process user.
For untrusted repositories, use a disposable environment without secrets. And passing local tests in this
environment is not official SWE-bench grading.

The experiment compares five configurations, on the same tasks, the same prompt, and the same code excerpt.
The baseline is unconstrained: up to ten attempts, with the whole conversation kept. Baseline K three is
also unconstrained, but has the same three-attempt cap and the same short context as H N E G. Reflex only adds
the Loop one check. Static mask adds the identifier-scope gate. Full adds the replay guard and the state
machine with graceful halt.

The comparison that matters most is full against baseline K three. Comparing full against the ten-attempt
baseline mostly measures the benefit of stopping early, which any agent could get from a simple cap. Full
against baseline K three isolates what the governance layers add. Note that the configurations are
cumulative, so each step measures one added layer on top of the previous ones, not each component in isolation.

For each task and configuration, the harness records every attempt: input and output tokens, generation
time, why an edit failed to apply, the reflex result, the test exit code, whether the patch repeated an
earlier one, any out-of-scope names it introduced, the stop reason, and the raw reply. These go into a JSON
lines file, with one CSV row per task. A metadata file records the model file's SHA-256, a fingerprint of the
code and configuration, the task-set hash, the GPU, and every setting. The harness refuses to resume a
results folder with a different model, code or settings. Summaries only use tasks completed by every
configuration.

Two definitions need care. First, the report's Pass at one column is the fraction of tasks resolved within the
configuration's attempt budget: up to three attempts for the governed arms, up to ten for the baseline. It is
not first-attempt success, and it should be read as resolved within budget. Second, the infinite-loop rate is
an operational definition: the task ran out of attempts while re-submitting an identical patch. That is
measurable on any run. But a zero rate shows that this specific behavior did not occur, not that loops are
impossible in general. Tokens per resolved task divides all tokens, including those spent on failed tasks, by
the number of resolved tasks. If nothing is resolved, it is undefined, not zero.

The claim-verification script makes this explicit. It sorts the paper's claims into two groups. Guarantees,
such as the attempt ceiling, no re-submitted failed patch, and no out-of-scope names, are properties of the
controller, checkable on any model. Effects, such as token savings, speedup, resolution rate, and cost per
resolved bug, are statistical. They use paired bootstrap confidence intervals and exact McNemar tests, and
they are marked verified, not supported, or inconclusive. Inconclusive means the data cannot decide, not that
the claim is false.

What evidence exists today? The test suite has sixty-eight tests, covering the state machine, the masks, the
trie, the replay guard, edit parsing, task preparation, the harness, the report, and claim verification. One
of them decodes with a tiny non-Gemma G G U F model, to check tokenization, masking and stopping on a real
llama dot C P P runtime. None of this measures repair quality.

On Kaggle, with a single T4 GPU, we ran the Gemma four E two B model on a two-bug pilot drawn from validated
SymPy tasks. The whole pipeline ran end to end. But no configuration produced an edit that could be applied,
so no bug was resolved, and every cost-per-resolved figure is undefined. One mechanism-level observation did
hold: in every configuration except full, the model re-submitted the identical failed patch on both bugs,
while full never did. With two bugs, that is an observation, not a statistical result. That pilot also
predates the edit-level replay guard. The current code switches the benchmark to the larger E four B model,
and that run has not been done yet.

So the percentages, token reductions and speedups in the white paper's results table are not verified
findings, and this recording does not present them as such. They were never produced by this code. Future
results from the E four B model must be reported as E four B results, with their sample size and confidence
intervals, and never relabeled as thirty-one-billion-parameter results.

The runnable configuration targets Gemma four E four B instruct, quantized as a Q four K M G G U F file of
about five gigabytes, running on llama dot C P P. File size is not total memory: fit and speed depend on the
context window, the hardware, and offload settings.

The next steps on Kaggle: attach the code and the cached llama dot C P P build, run the unit tests and the
sandbox checks, validate the tasks, and inspect one real prompt and reply before any long run. Then run a
two-bug timing pilot across all five configurations, read the replies, and only then run all validated
tasks. Validation keeps a SymPy instance only when its target tests fail on the original code and pass
with the official fix in this environment. Choosing task identifiers alone does not create a runnable
benchmark. The current pilot set has twenty tasks, not the hundred and twenty the paper describes.

The wider paper discusses interface generation, robotics and structured data extraction. Combining learned
generation with explicit constraints may well help there. But those remain proposed extensions, not validated
capabilities of this code-repair implementation.

So the contribution we can defend today is a testable local framework for bounded repair attempts,
identifier-scope masking, edit-level anti-replay, source-bound repository context, and transparent,
reproducible measurement. The hypothesis is that these mechanisms reduce wasted compute while preserving
useful repairs. The next milestone is to measure that hypothesis on a model that can actually produce repairs,
not to assume it is already proven.
